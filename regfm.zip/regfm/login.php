<!DOCTYPE html>

<head>
    <title>Login Form Design</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script type="text/javascript" src="js.js"></script>
</head>

<body>


    <div class="box">
        <img src="user.png" class="user">
        <h1>welcome to my page</h1>
    </div>
</body>
</html>