<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  


  <?php
  // define variables and set to empty values
  $uname1Err = $email1Err = $upswd1Err = $upswd2Err = "";
  $uname1 = $email1 = $upswd1 = $upswd2 ="";
  
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["uname1"])) {
      $uname1Err = "Name is required";
    } else {
      $uname1 = test_input($_POST["uname1"]);
      // check if name only contains letters and whitespace
      if (!preg_match("/^[a-zA-Z ]*$/",$uname1)) {
        $uname1Err = "Only letters and white space allowed";
      }
    }
    
    if (empty($_POST["email1"])) {
      $email1Err = "Email is required";
    } else {
      $email1 = test_input($_POST["email1"]);
      // check if e-mail address is well-formed
      if (!filter_var($email1, FILTER_VALIDATE_EMAIL)) {
        $email1Err = "Invalid email format";
      }
    }
  }
  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

$uname1 = $_POST['uname1'];
$email1  = $_POST['email1'];
$upswd1 = $_POST['upswd1'];
$upswd2 = $_POST['upswd2'];




if (!empty($uname1) || !empty($email1) || !empty($upswd1) || !empty($upswd2) )
{

$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "regfm";



// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);

if (mysqli_connect_error()){
  die('Connect Error ('. mysqli_connect_errno() .') '
    . mysqli_connect_error());
}
else{
  $SELECT = "SELECT email1 From register Where email1 = ? Limit 1";
  $INSERT = "INSERT Into register (uname1 , email1 ,upswd1, upswd2 )values(?,?,?,?)";

//selection 
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $email1);
     $stmt->execute();
     $stmt->bind_result($email1);
     $stmt->store_result();
     $rnum = $stmt->num_rows;

     //checking username and insertion
      if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ssss", $uname1,$email1,$upswd1,$upswd2);
      $stmt->execute();
      echo "New record inserted sucessfully";
     } else {
      echo "Someone already register using this email";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}

  
?>